n = input("Enter a alphabet :- ")
if(n in ['a','e','i','o','u','A','E','I','O','U']):
    print(n, "is a vowel.")
else:
    print(n, "is not a vowel.")