a = input("Enter first string :- ")
b = input("Enter second string :- ")
if(a == b):
    print("Both the strings are equal")
else:
    print("Both the strings are not equal")