n = int(input("Enter a day number from 0 to 6 :- "))
l = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
print("It is",l[n])