l = [0,20,37,100]
for i in l:
    f = (i * 9/5) + 32
    print(f"{i} C = {f} F")