def squt(a):
    return a**2

a = int(input("Enter a number :- "))
print(f"{a}^2 = {squt(a)}")