def sum(a,b):
    return a+b

a = int(input("Enter first number :- "))
b = int(input("Enter second number :- "))
print(f"{a}+{b} = {sum(a,b)}")