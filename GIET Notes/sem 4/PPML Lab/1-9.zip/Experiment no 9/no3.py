def display(name,age):
    print(name,age)
display(age=20, name="Ravi")