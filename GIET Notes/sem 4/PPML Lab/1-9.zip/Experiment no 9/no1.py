def add(a,b):
    return a+b
x = add(4,5)
print("Sum = ", x)
