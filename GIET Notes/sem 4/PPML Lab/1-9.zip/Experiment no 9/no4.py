def student(name,course):
    print("Name :", name)
    print("Course :", course)
student(course="python", name="Anu")