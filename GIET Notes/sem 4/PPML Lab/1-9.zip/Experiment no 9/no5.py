def greet(name = "Student"):
    print("Hello", name)
greet()