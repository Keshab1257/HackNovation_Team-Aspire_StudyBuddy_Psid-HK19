s = lambda n : n * n
print(s(4))
