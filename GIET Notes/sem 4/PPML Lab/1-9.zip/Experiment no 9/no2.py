def product(a,b):
    print("Product = ", a*b)
product(4,6)