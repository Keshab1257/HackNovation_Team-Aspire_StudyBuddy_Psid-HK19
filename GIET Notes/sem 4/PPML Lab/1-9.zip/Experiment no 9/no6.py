def bill(amount = 100):
    print("Bill amount :", amount)
bill(500)
bill()