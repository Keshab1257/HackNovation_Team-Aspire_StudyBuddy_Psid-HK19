#to input a string "Good morning friends how are you all" and do the opertaions: 
#display in reverse order of characters, split whole sentence into individual words and store as a lsit.

s = "Good morning friends how are you all"
print("In reverse order : ", s[::-1])
l = s.split(" ")
print("Spliting the words : ", l)