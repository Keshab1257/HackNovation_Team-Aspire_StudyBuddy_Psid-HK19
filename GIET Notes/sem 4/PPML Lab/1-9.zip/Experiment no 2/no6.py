#write a program to input a sentence and then the reverse  of it.
i = input("Enter a string :- ")
print("Reversed string is :- ",i[::-1])