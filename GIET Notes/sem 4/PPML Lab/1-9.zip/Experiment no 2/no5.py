#write a program to create a dictionary, store sample data and then display the key, values of it.
d = {
    "Name":"Rajesh Rana",
    "Roll Number":"24CSEAIML015",
    "Age":20
}
print("Dictionary data are :",d)
print("Keys are :- ", d.keys())
print("Values are :- ", d.values())