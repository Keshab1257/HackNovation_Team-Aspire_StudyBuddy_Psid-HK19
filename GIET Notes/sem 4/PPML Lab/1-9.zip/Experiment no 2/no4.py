#write a program to create a tuple and display the elements of it.
t = (15, "Rajesh Rana", 20, "Bhadrak")
print("Elements in the tuple are :- ", end = " ")
for i in t:
    print(i, end=", ")