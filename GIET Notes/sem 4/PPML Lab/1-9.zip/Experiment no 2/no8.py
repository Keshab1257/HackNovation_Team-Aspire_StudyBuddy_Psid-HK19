#to input a string "hello world". Display it in : upper case, lower case, 1st letter capitilized, find length

s = "hello world"
print(s, "in upper case : ",s.upper())
print(s, "in lower case : ", s.lower())
print(s, "in 1st capitalize : ", s.capitalize())
print(s, " length is : ", len(s))