#to input data for int, string, float, boolean,complex, and then display their data type

i = 20
s = "Rajesh"
f = 8.88
b = True
c = 2+7j
print("Datatype of i is : ", type(i))
print("Datatype of s is : ", type(s))
print("Datatype of f is : ", type(f))
print("Datatype of b is : ", type(b))
print("Datatype of c is : ", type(c))




