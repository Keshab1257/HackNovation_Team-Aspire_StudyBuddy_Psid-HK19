#write a program to input 1st name, mid name and last name into three variables and then apply concatenation.

a = input("Enter your 1st name :- ")
b = input("Enter your mid name :- ")
c = input("Enter your last name :- ")
full_name = a + b + c
print("Your name is ",full_name)