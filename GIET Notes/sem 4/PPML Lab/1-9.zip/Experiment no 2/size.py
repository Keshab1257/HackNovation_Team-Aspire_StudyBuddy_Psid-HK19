import sys
print('Size of integer :- ', sys.getsizeof(int()))
print('Size of float :- ', sys.getsizeof(float()))
print('Size of string :- ', sys.getsizeof(str()))
print('Size of list :- ', sys.getsizeof(list()))
print('Size of set :- ', sys.getsizeof(set()))
print('Size of tuple :- ', sys.getsizeof(tuple()))
print('Size of dict :- ', sys.getsizeof(dict()))