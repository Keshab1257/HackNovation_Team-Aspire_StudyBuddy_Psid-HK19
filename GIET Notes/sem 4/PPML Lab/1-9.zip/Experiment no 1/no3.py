#to find the area and perimeter of a circle 
r = int(input("Enter the radius : "))
print("Area is ",(3.14*r*r))
print("Perimeter is ",(2*3.14*r))