#input your marks for three subjects then find sum and percentage

a = int(input("Enter your first subject mark : "))
b = int(input("Enter your second subject mark : "))
c = int(input("Enter your third subject mark : "))
sum = a+b+c
per = sum/3
print("Total mark is : ", sum)
print("Percentage is : ", per)