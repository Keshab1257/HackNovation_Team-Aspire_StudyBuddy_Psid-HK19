#to print "welcome to python world"
print("Welcome to python world")