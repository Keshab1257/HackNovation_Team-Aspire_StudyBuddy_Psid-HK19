#to input two integers , find sum and product of them.

a = int(input("Enter first number : "))
b = int(input("Enter second number : "))

print(a," + ", b, " = ", (a + b))
print(a," X ", b, " = ", (a * b))