public class Cube{
    public static void main(String[] args) {
        int term = 4;
        for(int i = 1; i <= term; i++){
            System.out.println("Number is : " + i + " and cube of " + i + " is : " + (i*i*i));
        }
    }
}