import java.lang.*;
public class Main {
    public static void main(String[] args) {
        int a = 40, b = 30;
        System.out.println(a + "+" + b + "=" + (a+b));
        System.out.println(a + "-" + b + "=" + (a-b));
        System.out.println(a + "/" + b + "=" + (a/b));
        System.out.println(a + "*" + b + "=" + (a*b));
    }    
}
