import java.lang.*;
public class Main3 {
    public static void main(String[] args) {
        float l = 30f, b = 40f; 
        System.out.println("The area of rectangle is " + (l*b));
        System.out.println("The perimeter of rectangle is " + (2*(l+b)));
    }
}
