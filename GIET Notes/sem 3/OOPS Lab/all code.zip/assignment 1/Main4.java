import java.lang.*;
public class Main4 {
    public static void main(String[] args) {
        int c = 32;
        System.out.println(c + " Celsius in Fahrenheit is " + ((c*9.0/5)+32));
    }    
}
