//Rajesh/shape/Rectangle.java

package Rajesh.shape;
public class Rectangle {
    public int area(int l, int b) {
        return (l * b);
    }
    public int perimeter(int l, int b) {
        return (2*(l + b));
    }    
}
