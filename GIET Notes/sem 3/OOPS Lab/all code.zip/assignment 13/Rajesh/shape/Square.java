//Rajesh/shape/Square.java

package Rajesh.shape;
public class Square {
    public int area(int s) {
        return (s*s);
    }
    public int perimeter(int s) {
        return (4*s);
    }    
} 