//Rajesh/arithmetic/Multiplication.java
package Rajesh.arithmetic;

public class Multiplication {
    public int multiply(int a, int b) {
        return a * b;
    }
    public double multiply(double a, double b) {
        return a * b;
    }
}
