//Rajesh/arithmetic/Division.java
package Rajesh.arithmetic;

public class Division {
    public int divide(int a, int b) {
        return a / b;
    }

    public double divide(double a, double b) {
        return a / b;
    }
}
