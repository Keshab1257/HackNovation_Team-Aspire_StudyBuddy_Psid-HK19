import java.lang.*;
public class Name {
    public static void main(String[] args) {
        String a = args[0];
        String b = args[1];
        String c = args[2];
        System.out.println(a.charAt(0) + "." + b.charAt(0) + "." + c);
    }    
}
