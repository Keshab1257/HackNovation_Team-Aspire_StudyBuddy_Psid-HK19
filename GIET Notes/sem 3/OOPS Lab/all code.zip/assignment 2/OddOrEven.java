import java.lang.*;
public class OddOrEven {
    public static void main(String[] args) {
        int a = 401;
        if(a % 2 == 0){
            System.out.println(a + " is even");
        }
        else{
            System.out.println(a + " is odd");
        }
    }    
}
